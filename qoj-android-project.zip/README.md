# Qoj Android App

This is a complete Android Studio project for the Arabic Qoj control platform screen.

The app includes a custom adaptive launcher icon and stores the command text, selected
time, and date range locally with `SharedPreferences`, so those values remain after
the app is closed and reopened.

## Build

Open the project folder in Android Studio and let it sync with Gradle. Android Studio can build the APK from **Build > Build APK(s)**.

If Gradle 8.7+ is installed locally, you can also run:

```bash
gradle assembleDebug
```

The debug APK is generated at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

The project uses:

- Kotlin 2.0.21
- Android Gradle Plugin 8.5.2
- Compile/target SDK 35
- Minimum SDK 24
- Material Components 1.12.0

On Android 13 and newer, the app requests `POST_NOTIFICATIONS` when it opens. The notification button also checks the permission before attempting to post a notification.