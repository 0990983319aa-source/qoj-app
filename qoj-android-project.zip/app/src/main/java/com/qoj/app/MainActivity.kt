package com.qoj.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.widget.NestedScrollView
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.button.MaterialButton
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private companion object {
        const val CHANNEL_ID = "qoj_notifications_channel"
        const val NOTIFICATION_PERMISSION_REQUEST_CODE = 1001
        const val NOTIFICATION_ID = 101
        const val PREFERENCES_NAME = "qoj_preferences"
        const val KEY_COMMAND = "command"
        const val KEY_TIME = "time"
        const val KEY_DATE_START = "date_start"
        const val KEY_DATE_END = "date_end"
    }

    private val preferences by lazy {
        getSharedPreferences(PREFERENCES_NAME, MODE_PRIVATE)
    }

    private lateinit var commandInput: TextInputEditText
    private lateinit var timeButton: MaterialButton
    private lateinit var dateRangeButton: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        restoreSavedState()
        bindPersistenceListeners()
        createNotificationChannel()
        requestNotificationPermissionIfNeeded()
    }

    private fun buildUi(): View {
        val coordinatorLayout = CoordinatorLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Color.parseColor("#121212"))
        }

        val appBarLayout = AppBarLayout(this).apply {
            layoutParams = AppBarLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setBackgroundColor(Color.parseColor("#1E1E1E"))
        }

        val toolbar = MaterialToolbar(this).apply {
            layoutParams = MaterialToolbar.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            title = getString(R.string.app_name)
            setTitleTextColor(Color.WHITE)
        }
        appBarLayout.addView(toolbar)
        coordinatorLayout.addView(appBarLayout)

        val scrollView = NestedScrollView(this).apply {
            layoutParams = CoordinatorLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ).apply {
                behavior = AppBarLayout.ScrollingViewBehavior()
            }
            setPadding(24.dp, 24.dp, 24.dp, 24.dp)
            clipToPadding = false
        }

        val contentLayout = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            orientation = LinearLayout.VERTICAL
        }

        val inputLayout = TextInputLayout(
            this,
            null,
            com.google.android.material.R.style.Widget_Material3_TextInputLayout_OutlinedBox
        ).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = 16.dp
            }
            hint = "أدخل اسم النشاط أو الأمر"
            isCounterEnabled = true
            counterMaxLength = 50
            endIconMode = TextInputLayout.END_ICON_CLEAR_TEXT
        }

        commandInput = TextInputEditText(inputLayout.context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            setTextColor(Color.WHITE)
            setSingleLine(true)
        }
        inputLayout.addView(commandInput)
        contentLayout.addView(inputLayout)

        val buttonsRow = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = 16.dp
            }
            orientation = LinearLayout.HORIZONTAL
        }

        timeButton = MaterialButton(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            ).apply {
                marginEnd = 8.dp
            }
            text = "تحديد الوقت"
            setOnClickListener { showTimePicker() }
        }

        dateRangeButton = MaterialButton(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            ).apply {
                marginStart = 8.dp
            }
            text = "نطاق التاريخ"
            setOnClickListener { showDateRangePicker() }
        }

        buttonsRow.addView(timeButton)
        buttonsRow.addView(dateRangeButton)
        contentLayout.addView(buttonsRow)

        val bottomSheetButton = MaterialButton(
            this,
            null,
            com.google.android.material.R.style.Widget_Material3_Button_TonalButton
        ).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = 12.dp
            }
            text = "عرض قائمة الخيارات"
            setOnClickListener { showBottomSheet() }
        }
        contentLayout.addView(bottomSheetButton)

        val notificationButton = MaterialButton(
            this,
            null,
            com.google.android.material.R.style.Widget_Material3_Button_OutlinedButton
        ).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            text = "إرسال إشعار تحديث"
            setOnClickListener { triggerNotification(5) }
        }
        contentLayout.addView(notificationButton)

        scrollView.addView(contentLayout)
        coordinatorLayout.addView(scrollView)
        return coordinatorLayout
    }

    private fun showTimePicker() {
        val timePicker = MaterialTimePicker.Builder()
            .setTimeFormat(TimeFormat.CLOCK_12H)
            .setHour(12)
            .setMinute(0)
            .setTitleText("اختر الوقت المناسب")
            .build()

        timePicker.addOnPositiveButtonClickListener {
            val formattedTime = String.format(
                Locale.getDefault(),
                "%02d:%02d",
                timePicker.hour,
                timePicker.minute
            )
            timeButton.text = "الوقت: $formattedTime"
            preferences.edit().putString(KEY_TIME, formattedTime).apply()
            Toast.makeText(this, "الوقت المحدد: $formattedTime", Toast.LENGTH_SHORT).show()
        }
        timePicker.show(supportFragmentManager, "TIME_PICKER")
    }

    private fun showDateRangePicker() {
        val dateRangePicker = MaterialDatePicker.Builder.dateRangePicker()
            .setTitleText("تحديد نطاق التاريخ")
            .build()

        dateRangePicker.addOnPositiveButtonClickListener { selection ->
            val formatter = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
            val startDate = formatter.format(Date(selection.first))
            val endDate = formatter.format(Date(selection.second))
            dateRangeButton.text = "$startDate - $endDate"
            preferences.edit()
                .putLong(KEY_DATE_START, selection.first)
                .putLong(KEY_DATE_END, selection.second)
                .apply()
            Toast.makeText(this, "تم اختيار النطاق الزمني بنجاح", Toast.LENGTH_SHORT).show()
        }
        dateRangePicker.show(supportFragmentManager, "DATE_RANGE_PICKER")
    }

    private fun showBottomSheet() {
        val dialog = BottomSheetDialog(this)
        val sheetLayout = LinearLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1E1E1E"))
            setPadding(24.dp, 16.dp, 24.dp, 24.dp)
        }

        val handleBar = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(60.dp, 6.dp).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = 16.dp
            }
            setBackgroundColor(Color.parseColor("#444444"))
        }

        val actionButton = MaterialButton(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            text = "تنفيذ العملية الحالية"
            setOnClickListener {
                Toast.makeText(this@MainActivity, "جاري التنفيذ...", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
        }

        val cancelButton = MaterialButton(
            this,
            null,
            com.google.android.material.R.style.Widget_Material3_Button_TextButton
        ).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            text = "إلغاء"
            setTextColor(Color.parseColor("#FF5555"))
            setOnClickListener { dialog.dismiss() }
        }

        sheetLayout.addView(handleBar)
        sheetLayout.addView(actionButton)
        sheetLayout.addView(cancelButton)
        dialog.setContentView(sheetLayout)
        dialog.show()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "إشعارات النظام",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "قناة إشعارات منصة القيادة"
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                NOTIFICATION_PERMISSION_REQUEST_CODE
            )
        }
    }

    private fun triggerNotification(count: Int) {
        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, "يرجى السماح بالإشعارات أولاً", Toast.LENGTH_SHORT).show()
            requestNotificationPermissionIfNeeded()
            return
        }

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("تحديث منصة القيادة")
            .setContentText("لديك $count إشعارات جديدة بانتظارك")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification)
    }

    private fun restoreSavedState() {
        preferences.getString(KEY_COMMAND, null)?.let { savedCommand ->
            commandInput.setText(savedCommand)
            commandInput.setSelection(savedCommand.length)
        }

        preferences.getString(KEY_TIME, null)?.let { savedTime ->
            timeButton.text = "الوقت: $savedTime"
        }

        val savedStart = preferences.getLong(KEY_DATE_START, -1L)
        val savedEnd = preferences.getLong(KEY_DATE_END, -1L)
        if (savedStart >= 0L && savedEnd >= 0L) {
            dateRangeButton.text = formatDateRange(savedStart, savedEnd)
        }
    }

    private fun bindPersistenceListeners() {
        commandInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(
                text: CharSequence?,
                start: Int,
                count: Int,
                after: Int
            ) = Unit

            override fun onTextChanged(
                text: CharSequence?,
                start: Int,
                before: Int,
                count: Int
            ) {
                preferences.edit()
                    .putString(KEY_COMMAND, text?.toString().orEmpty())
                    .apply()
            }

            override fun afterTextChanged(editable: Editable?) = Unit
        })
    }

    private fun formatDateRange(startMillis: Long, endMillis: Long): String {
        val formatter = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
        return "${formatter.format(Date(startMillis))} - ${formatter.format(Date(endMillis))}"
    }

    private val Int.dp: Int
        get() = (this * resources.displayMetrics.density).roundToInt()

    private fun Float.roundToInt(): Int = kotlin.math.round(this).toInt()
}